# UIMenuItem

## 方法

```objective-c
- (instancetype)initWithTitle:(NSString *)title actionBlock:(void (^) (id sender))block;

```


