
> Category

- 返回自己对应的罗马数字

```objective-c
- (NSString *)ll_romanNumeral;
```

- 四舍五入

```oc
- (NSNumber *)ll_doRoundWithDigit:(NSUInteger)digit;
```

- 取上整

```oc
- (NSNumber *)ll_doCeilWithDigit:(NSUInteger)digit;
```

- 取下整

```oc
- (NSNumber *)ll_doFloorWithDigit:(NSUInteger)digit;
```


