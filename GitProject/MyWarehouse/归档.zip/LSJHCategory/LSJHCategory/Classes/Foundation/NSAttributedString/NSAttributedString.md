# NSAttributedString
## 功能

- 动态计算NSAttributedString的高度

## 方法
```objective-c
/**
 Get the AttributedString height

 @param width AttributedString Width
 @return AttributedString height
 */
- (CGFloat)ll_heightWithContainWidth:(CGFloat)width;
```


