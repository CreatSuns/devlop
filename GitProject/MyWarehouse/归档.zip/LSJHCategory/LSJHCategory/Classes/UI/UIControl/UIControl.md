> category

| 属性 | 注释 |
| --- | --- |
| debounceTime | 防抖保护时长 |
| endTime | 上次事件触发保护期 |




