//
//  UIView+Gestures.h
//
//  Created by 李世航 on 2018/12/11.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, LLTapGesturesStyle) {
    LLTapGesturesStyleSingle,
    LLTapGesturesStyleDouble,
};

NS_ASSUME_NONNULL_BEGIN
/// 使用这种方式只能使用单次，如果涉及到多个同一种手势、手势代理请在外部自行添加手势
@interface UIView (Gestures)

/**
 添加点击手势

 @param tapStyle 点击类型
 @param handle 回调
 */
- (void)ll_AddTapGesturesWithTapStyle:(LLTapGesturesStyle)tapStyle
                            TapHandle:(void (^)(UITapGestureRecognizer * gesture))handle;

/**
 添加长按手势

 @param duration 长按时间
 @param handle 回调
 */
- (void)ll_AddLongPressGestureWithDuration:(NSTimeInterval)duration
                                    Handle:
                                     (void (^)(UILongPressGestureRecognizer * gesture))handle;

/**
 添加平移手势

 @param handle 回调
 */
- (void)ll_AddPanGestureWithHandle:(void (^)(UIPanGestureRecognizer * gesture))handle;

/**
 添加轻扫手势

 @param direction 方向
 @param handle 回调
 */
- (void)ll_AddSwipeGestureWithSwipeDirection:(UISwipeGestureRecognizerDirection)direction
                                 SwipeHandle:(void (^)(UISwipeGestureRecognizer * gesture))handle;

/**
 添加旋转手势

 @param handle 回调
 */
- (void)ll_AddRotationGestureWithHandle:(void (^)(UIRotationGestureRecognizer * gesture))handle;

/**
 添加捏合手势

 @param handle 回调
 */
- (void)ll_AddPinchGestureWithHandle:(void (^)(UIPinchGestureRecognizer * gesture))handle;
@end

NS_ASSUME_NONNULL_END
