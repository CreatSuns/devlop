//
//  LLViewController.m
//  LSJHCategory
//
//  Created by 1228506851@qq.com on 04/22/2020.
//  Copyright (c) 2020 1228506851@qq.com. All rights reserved.
//

#import "LLViewController.h"

@interface LLViewController ()

@end

@implementation LLViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
