//
//  UIScrollView+Category.h
//
//  Created by 李世航 on 2019/7/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (Category)

/// 截图
- (UIImage *)ll_captureScrollView;
@end

NS_ASSUME_NONNULL_END
