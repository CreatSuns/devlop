> Animation

- 暂停动画

```
- (void)pause;
```
- 恢复动画

```
- (void)resume;
```




